#!/usr/bin/env python

"""
    __init__
    ~~~~~~~~

    Package intialization.

    :author: Fahad Khalid
    :license: MIT, see LICENSE for more details.
"""
